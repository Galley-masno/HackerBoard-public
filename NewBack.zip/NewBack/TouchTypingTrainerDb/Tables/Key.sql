CREATE TABLE dbo.[Key] (
  Position int NOT NULL
);