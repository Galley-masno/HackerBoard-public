CREATE TABLE dbo.[Group] (
  Group_UID int IDENTITY(1,1),
  [Name] nvarchar(100) NOT NULL
    CONSTRAINT DF_Group_Name
      DEFAULT ('')
);

