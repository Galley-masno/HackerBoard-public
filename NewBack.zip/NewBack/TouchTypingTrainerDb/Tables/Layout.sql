CREATE TABLE dbo.Layout (
  Layout_UID int IDENTITY(1,1),
  [Name] nvarchar(50) NOT NULL
    CONSTRAINT DF_Layout_Name
      DEFAULT ('')
);