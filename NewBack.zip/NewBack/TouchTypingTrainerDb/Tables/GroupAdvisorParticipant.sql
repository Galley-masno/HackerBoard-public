CREATE TABLE dbo.GroupAdvisorParticipant (
  GroupAdvisorParticipant_UID int IDENTITY(1,1),
  AdvisorUserFID nvarchar(450) NOT NULL,
  ParticipantUserFID nvarchar(450) NOT NULL,
  GroupFID int NOT NULL,
    CONSTRAINT CK_AdvisorNotParticipant
      CHECK (AdvisorUserFID <> ParticipantUserFID)
);
