CREATE TABLE dbo.UserCourseProgress (
  UserCourseProgress_UID int IDENTITY(1,1),
  IsCompleted bit NOT NULL
    CONSTRAINT DF_UserCourseProgress_IsCompleted
      DEFAULT (0),
  CurrentExerciseFID int NOT NULL,
  CurrentLessonFID int NOT NULL,
  CourseFID int NOT NULL,
  UserFID nvarchar(450) NOT NULL
);
