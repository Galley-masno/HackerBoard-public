CREATE TABLE dbo.LayoutKeys (
  LayoutKeys_UID int IDENTITY(1,1),
  [Value] nchar(1) NOT NULL
    CONSTRAINT DF_LayoutKeys_Value
      DEFAULT (''),
  ShiftValue nchar(1) NOT NULL
    CONSTRAINT DF_LayoutKeys_ShiftValue
      DEFAULT (''),
  KeyFID int NOT NULL,
  LayoutFID int NOT NULL
);