CREATE TABLE dbo.Lesson (
  Lesson_UID int IDENTITY(1,1),
  Title nvarchar(50) NOT NULL
    CONSTRAINT DF_Lesson_Title
      DEFAULT (''),
  [Description] nvarchar(150)
    CONSTRAINT DF_Lesson_Description
      DEFAULT (''),
  CourseFID int NOT NULL,
);
