CREATE TABLE dbo.Exercise (
  Exercise_UID int IDENTITY(1,1),
  Title nvarchar(50)
    CONSTRAINT DF_Exercise_Title
      DEFAULT (''),
  StudySet nvarchar(200) NOT NULL
    CONSTRAINT DF_Exercise_StudySet
      DEFAULT (''),
  LessonFID int NOT NULL
);
