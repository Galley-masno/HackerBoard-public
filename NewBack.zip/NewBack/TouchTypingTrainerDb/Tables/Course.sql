CREATE TABLE dbo.Course (
  Course_UID int IDENTITY(1,1),
  Title nvarchar(50) NOT NULL
    CONSTRAINT DF_Course_Title
      DEFAULT (''),
  [Description] nvarchar(150) NOT NULL
    CONSTRAINT DF_Course_Description
      DEFAULT (''),
  LayoutFID int NOT NULL
);
