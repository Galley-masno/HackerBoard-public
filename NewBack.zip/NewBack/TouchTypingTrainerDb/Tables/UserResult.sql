CREATE TABLE dbo.UserResult (
  UserResult_UID int IDENTITY(1,1),
  Accuracy real NOT NULL
    CONSTRAINT DF_UserResult_Accuracy
      DEFAULT (0.0),
  Speed int NOT NULL
    CONSTRAINT DF_UserResult_Speed
      DEFAULT (0),
  ResultType tinyint NOT NULL -- 0-exercise, 1-testing material
    CONSTRAINT DF_UserResult_ResultType
      DEFAULT (0),
  CreatedAt date NOT NULL
    CONSTRAINT DF_TestingMaterial_CreatedAt
      DEFAULT getdate(),
  UserFID nvarchar(450) NOT NULL,
  TestingMaterialFID int,
  ExerciseFID int,
  CONSTRAINT CK_OneResultForeignKeyNotNull
    CHECK (TestingMaterialFID IS NOT NULL OR
      ExerciseFID IS NOT NULL),
);
