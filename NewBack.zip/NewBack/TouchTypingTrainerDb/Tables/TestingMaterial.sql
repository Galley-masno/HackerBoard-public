CREATE TABLE dbo.TestingMaterial (
  TestingMaterial_UID int IDENTITY(1,1),
  [Text] nvarchar(max) NOT NULL
    CONSTRAINT DF_TestingMaterial_Text
      DEFAULT (''),
  LayoutFID int NOT NULL
);
