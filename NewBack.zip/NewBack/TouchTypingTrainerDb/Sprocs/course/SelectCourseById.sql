CREATE OR ALTER PROCEDURE dbo.SelectCourseById
  @CourseId int,
  @IncludeLessonsWithExercises bit
  AS
    SELECT
      Course_UID,
      Title,
      [Description],
      LayoutFID
    FROM dbo.Course
    WHERE Course_UID = @CourseId;

    IF @IncludeLessonsWithExercises = 1
      BEGIN
        SELECT
          l.Lesson_UID,
          l.Title AS Lesson_Title,
          l.[Description],
          l.CourseFID,
          e.Exercise_UID,
          e.Title AS Exercise_Title,
          e.StudySet,
          e.LessonFID
        FROM dbo.Lesson AS l
          JOIN dbo.Exercise AS e
            ON l.Lesson_UID = e.LessonFID
        WHERE l.CourseFID = @CourseId;
      END
  GO
