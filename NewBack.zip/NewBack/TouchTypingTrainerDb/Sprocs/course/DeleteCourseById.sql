CREATE OR ALTER PROCEDURE dbo.DeleteCourseById
  @CourseId int
  AS
    DELETE FROM dbo.Course
    WHERE Course_UID = @CourseId;
  GO
