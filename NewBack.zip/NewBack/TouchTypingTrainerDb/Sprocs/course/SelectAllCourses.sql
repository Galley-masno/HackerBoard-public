CREATE OR ALTER PROCEDURE dbo.SelectAllCourses
  AS
    SELECT
      Course_UID,
      Title,
      [Description],
      LayoutFID
    FROM dbo.Course;
  GO
