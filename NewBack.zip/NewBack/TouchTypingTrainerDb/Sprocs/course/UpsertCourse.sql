CREATE OR ALTER PROCEDURE dbo.UpsertCourse
  @CourseId int = NULL,
  @Title nvarchar(50),
  @Description nvarchar(150),
  @LayoutId int
  AS
    IF NOT EXISTS ( SELECT
                      1
                    FROM dbo.Layout
                    WHERE Layout_UID = @LayoutId )
      THROW 50000, 'Related layout does not exist.', 1;

    IF @CourseId IS NOT NULL
      UPDATE dbo.Course
        SET
          Title = @Title,
          [Description] = @Description,
          LayoutFID = @LayoutId
      WHERE Course_UID = @CourseId;
    ELSE
      INSERT INTO dbo.Course (
        Title,
        [Description],
        LayoutFID
      )
      VALUES (
        @Title,
        @Description,
        @LayoutId
      );
  GO
