CREATE OR ALTER PROCEDURE dbo.SelectTestingMaterialById
  @TestingMaterialId int
  AS
    SELECT
      TestingMaterial_UID,
      [Text],
      LayoutFID
    FROM dbo.TestingMaterial
    WHERE TestingMaterial_UID = @TestingMaterialId;
  GO
