CREATE OR ALTER PROCEDURE dbo.DeleteTestingMaterialById
  @TestingMaterialId int
  AS
    DELETE FROM dbo.TestingMaterial
    WHERE TestingMaterial_UID = @TestingMaterialId;
  GO
