CREATE OR ALTER PROCEDURE dbo.UpsertTestingMaterial
  @TestingMaterialId int = NULL,
  @Text nvarchar(max),
  @LayoutId int
  AS
    IF NOT EXISTS ( SELECT
                      1
                    FROM dbo.Layout
                    WHERE Layout_UID = @LayoutId )
      THROW 50000, 'Related layout does not exist.', 1;

    IF @TestingMaterialId IS NOT NULL
      UPDATE dbo.TestingMaterial
        SET
          [Text] = @Text,
          LayoutFID = @LayoutId
      WHERE TestingMaterial_UID = @TestingMaterialId;
    ELSE
      INSERT INTO dbo.TestingMaterial (
        [Text],
        LayoutFID
      )
      VALUES (
        @Text,
        @LayoutId
      );
  GO
