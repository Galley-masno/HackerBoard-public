CREATE OR ALTER PROCEDURE dbo.SelectAllTestingMaterials
  @LayoutId int
  AS
    SELECT
      TestingMaterial_UID,
      [Text],
      LayoutFID
    FROM dbo.TestingMaterial
    WHERE LayoutFID = @LayoutId;
  GO
