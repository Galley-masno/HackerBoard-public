CREATE OR ALTER PROCEDURE dbo.SelectUserCourses
  @UserId nvarchar(450)
  AS
    SELECT
      c.Course_UID,
      c.Title,
      c.[Description]
    FROM dbo.Course AS c
      JOIN dbo.UserCourseProgress AS p
        ON c.Course_UID = p.CourseFID
    WHERE p.UserFID = @UserId;
  GO
