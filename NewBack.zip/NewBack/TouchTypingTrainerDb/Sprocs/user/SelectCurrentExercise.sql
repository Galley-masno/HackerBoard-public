CREATE OR ALTER PROCEDURE dbo.SelectCurrentExercise
  @UserId nvarchar(450),
  @CourseId int
  AS
    SELECT
      e.Exercise_UID,
      e.Title,
      e.StudySet,
      e.LessonFID
    FROM dbo.Exercise AS e
      JOIN dbo.UserCourseProgress AS p
        ON e.Exercise_UID = p.CurrentExerciseFID
    WHERE p.UserFID = @UserId
      AND p.CourseFID = @CourseId;
  GO
