CREATE OR ALTER PROCEDURE dbo.SelectUserLearningResults
  @UserId nvarchar(450),
  @CourseId int
  AS
    SELECT
      ur.UserResult_UID,
      ur.Accuracy,
      ur.Speed,
      ur.CreatedAt,
      ur.ExerciseFID
    FROM dbo.Lesson AS l
      JOIN dbo.Exercise AS e
        ON l.Lesson_UID = e.LessonFID
      JOIN dbo.UserResult AS ur
        ON e.Exercise_UID = ur.ExerciseFID
    WHERE ur.UserFID = @UserId
      AND ur.ResultType = 0 -- exercise
      AND l.CourseFID = @CourseId;
  GO
