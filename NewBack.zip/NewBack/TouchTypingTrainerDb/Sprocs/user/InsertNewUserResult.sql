CREATE OR ALTER PROCEDURE dbo.InsertNewUserResult
  @Accuracy real,
  @Speed int,
  @ResultType tinyint,
  @CreatedAt date,
  @UserId nvarchar(450),
  @TestingMaterialId int = NULL,
  @ExerciseId int = NULL
  AS
    IF NOT EXISTS ( SELECT
                      1
                    FROM dbo.AspNetUsers
                    WHERE Id = @UserId )
      THROW 50000, 'Related user does not exist', 1;

    DECLARE
      @TestingMaterialIdLocal int = NULL,
      @ExerciseIdLocal int = NULL;

    IF @ResultType = 0 --exercise
      BEGIN
        IF NOT EXISTS ( SELECT
                          1
                        FROM dbo.Exercise
                        WHERE Exercise_UID = @ExerciseId )
          THROW 50000, 'Related exercise does not exist', 1;
        SET @ExerciseIdLocal = @ExerciseId;
      END
    ELSE IF @ResultType = 1 --testing material
      BEGIN
        IF NOT EXISTS ( SELECT
                          1
                        FROM dbo.TestingMaterial
                        WHERE TestingMaterial_UID = @TestingMaterialId )
          THROW 50000, 'Related testing material does not exist', 1;
        SET @TestingMaterialIdLocal = @TestingMaterialId;
      END

        INSERT INTO dbo.UserResult (
          Accuracy,
          Speed,
          ResultType,
          CreatedAt,
          UserFID,
          TestingMaterialFID,
          ExerciseFID
        )
        VALUES (
          @Accuracy,
          @Speed,
          @ResultType,
          @CreatedAt,
          @UserId,
          @TestingMaterialIdLocal,
          @ExerciseIdLocal
        );
  GO
