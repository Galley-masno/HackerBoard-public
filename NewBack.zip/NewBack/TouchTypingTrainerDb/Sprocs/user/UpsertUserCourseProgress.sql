CREATE OR ALTER PROCEDURE dbo.UpsertUserCourseProgress
  @UserId nvarchar(450),
  @CourseId int
  AS
    IF NOT EXISTS ( SELECT
                      1
                    FROM dbo.AspNetUsers
                    WHERE Id = @UserId )
      THROW 50000, 'Related user does not exist.', 1;

    IF NOT EXISTS ( SELECT
                      1
                    FROM dbo.Course
                    WHERE Course_UID = @CourseId )
      THROW 50000, 'Related course does not exist.', 1;

    DECLARE @IsCompleted bit = 0;

    IF NOT EXISTS ( SELECT
                      1
                    FROM dbo.UserCourseProgress
                    WHERE UserFID = @UserId
                      AND CourseFID = @CourseId )
      BEGIN
        DECLARE
          @FirstLessonId int,
          @FirstExerciseId int;
        
        SELECT TOP 1
          @FirstExerciseId = e.Exercise_UID,
          @FirstLessonId = l.Lesson_UID
        FROM dbo.Lesson AS l
          JOIN dbo.Exercise AS e
            ON l.Lesson_UID = e.LessonFID
        WHERE l.CourseFID = @CourseId
        ORDER BY e.Exercise_UID ASC;
        
        INSERT INTO dbo.UserCourseProgress (
          IsCompleted,
          CurrentExerciseFID,
          CurrentLessonFID,
          CourseFID,
          UserFID
        )
        VALUES (
          @IsCompleted,
          @FirstExerciseId,
          @FirstLessonId,
          @CourseId,
          @UserId
        );
      END
    ELSE
      BEGIN
        DECLARE
          @CurrentExerciseId int,
          @CurrentLessonId int,
          @NextExerciseId int,
          @NextLessonId int;
        
        -- Retrieves the Course status and the current Lesson,
        -- Exercise for the selected User's Course.
        SELECT TOP 1
          @IsCompleted = IsCompleted,
          @CurrentExerciseId = CurrentExerciseFID,
          @CurrentLessonId = CurrentLessonFID
        FROM dbo.UserCourseProgress
        WHERE UserFID = @UserId
          AND CourseFID = @CourseId;
        
        IF @IsCompleted = 1
          RETURN;
        
        -- Finds the next Lesson and Exercise.
        SELECT TOP 1
          @NextExerciseId = e.Exercise_UID,
          @NextLessonId = e.LessonFID
        FROM dbo.Lesson AS l
          JOIN dbo.Exercise AS e
            ON l.Lesson_UID = e.LessonFID
        WHERE l.CourseFID = @CourseId
          AND e.Exercise_UID > @CurrentExerciseId
        ORDER BY Exercise_UID ASC;
        
        -- If there are no next Lesson and Exercise,
        -- mark the course as completed.
        IF ( @NextExerciseId IS NULL
               AND @NextLessonId IS NULL )
          BEGIN
            SET @IsCompleted = 1;
            UPDATE dbo.UserCourseProgress
              SET
                IsCompleted = @IsCompleted
            WHERE CourseFID = @CourseId
              AND UserFID = @UserId;
          END
        -- Otherwise, set the next Exercise and Lesson.
        ELSE
          UPDATE dbo.UserCourseProgress
            SET
              CurrentExerciseFID = @NextExerciseId,
              CurrentLessonFID = @NextLessonId
          WHERE CourseFID = @CourseId
            AND UserFID = @UserId;
      END
  GO
