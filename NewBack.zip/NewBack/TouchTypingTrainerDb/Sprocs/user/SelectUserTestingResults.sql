CREATE OR ALTER PROCEDURE dbo.SelectUserTestingResults
  @UserId nvarchar(450)
  AS
    SELECT
      UserResult_UID,
      Accuracy,
      Speed,
      CreatedAt
    FROM dbo.UserResult
    WHERE UserFID = @UserId
      AND ResultType = 1; -- testing material
  GO
