CREATE OR ALTER PROCEDURE dbo.UpsertLesson
  @LessonId int = NULL,
  @Title nvarchar(50),
  @Description nvarchar(150),
  @CourseId int
  AS
    IF NOT EXISTS ( SELECT
                      1
                    FROM dbo.Course
                    WHERE Course_UID = @CourseId)
      THROW 50000, 'Related course does not exist', 1;

    IF @LessonId IS NOT NULL
      UPDATE dbo.Lesson
        SET
          Title = @Title,
          [Description] = @Description,
          CourseFID = @CourseId
      WHERE Lesson_UID = @LessonId;
    ELSE
      INSERT INTO dbo.Lesson (
        Title,
        [Description],
        CourseFID
      )
      VALUES (
        @Title,
        @Description,
        @CourseId
      );
  GO
