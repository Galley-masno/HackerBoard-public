CREATE OR ALTER PROCEDURE dbo.SelectLessonById
  @LessonId int
  AS
    SELECT
      Lesson_UID,
      Title,
      [Description],
      CourseFID
    FROM dbo.Lesson
    WHERE Lesson_UID = @LessonId;
  GO
