CREATE OR ALTER PROCEDURE dbo.SelectAllLessons
  AS
    SELECT
      Lesson_UID,
      Title,
      [Description],
      CourseFID
    FROM dbo.Lesson;
  GO
