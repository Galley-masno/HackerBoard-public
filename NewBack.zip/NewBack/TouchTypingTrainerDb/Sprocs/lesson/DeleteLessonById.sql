CREATE OR ALTER PROCEDURE dbo.DeleteLessonById
  @LessonId int
  AS
    DELETE FROM dbo.Lesson
    WHERE Lesson_UID = @LessonId;
  GO
