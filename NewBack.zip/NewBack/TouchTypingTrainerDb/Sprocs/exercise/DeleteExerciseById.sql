CREATE OR ALTER PROCEDURE dbo.DeleteExerciseById
  @ExerciseId int
  AS
    DELETE FROM dbo.Exercise
    WHERE Exercise_UID = @ExerciseId;
  GO
