CREATE OR ALTER PROCEDURE dbo.SelectAllExercises
  AS
    SELECT
      Exercise_UID,
      Title,
      StudySet,
      LessonFID
    FROM dbo.Exercise;
  GO
