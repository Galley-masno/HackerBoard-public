CREATE OR ALTER PROCEDURE dbo.UpsertExercise
  @ExerciseId int = NULL,
  @Title nvarchar(50),
  @StudySet nvarchar(200),
  @LessonId int
  AS
    IF NOT EXISTS ( SELECT
                      1
                    FROM dbo.Lesson
                    WHERE Lesson_UID = @LessonId )
      THROW 50000, 'Related lesson does not exist.', 1;

    IF @ExerciseId IS NOT NULL
      UPDATE dbo.Exercise
        SET
          Title = @Title,
          StudySet = @StudySet,
          LessonFID = @LessonId
      WHERE Exercise_UID = @ExerciseId;
    ELSE
      INSERT INTO dbo.Exercise (
        Title,
        StudySet,
        LessonFID
      )
      VALUES (
        @Title,
        @StudySet,
        @LessonId
      );
  GO
