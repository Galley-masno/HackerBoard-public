CREATE OR ALTER PROCEDURE dbo.SelectExerciseById
  @ExerciseId int
  AS
    SELECT
      Exercise_UID,
      Title,
      StudySet,
      LessonFID
    FROM dbo.Exercise
    WHERE Exercise_UID = @ExerciseId;
  GO
