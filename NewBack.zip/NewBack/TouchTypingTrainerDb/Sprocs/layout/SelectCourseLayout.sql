CREATE OR ALTER PROCEDURE dbo.SelectCourseLayout
  @CourseId int
  AS
    SELECT
      lk.[Value],
      lk.ShiftValue,
      lk.KeyFID
    FROM dbo.Layout AS l
    JOIN dbo.Course AS c
      ON l.Layout_UID = c.LayoutFID
    JOIN dbo.LayoutKeys as lk
      ON l.Layout_UID = lk.LayoutFID
    WHERE c.Course_UID = @CourseId;
  GO
