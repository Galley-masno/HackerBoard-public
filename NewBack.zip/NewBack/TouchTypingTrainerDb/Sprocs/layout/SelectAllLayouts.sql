CREATE OR ALTER PROCEDURE dbo.SelectAllLayouts
  AS
    SELECT
      Layout_UID,
      [Name]
    FROM dbo.Layout;
  GO
