DECLARE @TableName varchar(50) = 'dbo.Exercise';

PRINT 'Create table ' + @TableName;
IF NOT EXISTS ( SELECT
                  1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                  AND TABLE_NAME = 'Exercise' )
  BEGIN
    CREATE TABLE dbo.Exercise (
      Exercise_UID int IDENTITY(1,1),
      Title nvarchar(50)
        CONSTRAINT DF_Exercise_Title
          DEFAULT (''),
      StudySet nvarchar(200) NOT NULL
        CONSTRAINT DF_Exercise_StudySet
          DEFAULT (''),
      LessonFID int NOT NULL,
      CONSTRAINT PK_Exercise
        PRIMARY KEY ( Exercise_UID ),
      CONSTRAINT FK_Exercise_Lesson
        FOREIGN KEY ( LessonFID )
          REFERENCES dbo.Lesson ( Lesson_UID )
          ON DELETE CASCADE
    );
    PRINT 'Done.';
  END
ELSE
  PRINT 'The table already exists.';
