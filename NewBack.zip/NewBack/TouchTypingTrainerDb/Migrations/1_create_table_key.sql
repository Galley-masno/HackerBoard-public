DECLARE @TableName varchar(50) = 'dbo.Key';

PRINT 'Create table ' + @TableName;
IF NOT EXISTS ( SELECT
                  1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                  AND TABLE_NAME = 'Key' )
  BEGIN
    CREATE TABLE dbo.[Key] (
      Position int NOT NULL,
      CONSTRAINT PK_Key
        PRIMARY KEY ( Position )
    );
    PRINT 'Done.';
  END
ELSE
  PRINT 'The table already exists.';
