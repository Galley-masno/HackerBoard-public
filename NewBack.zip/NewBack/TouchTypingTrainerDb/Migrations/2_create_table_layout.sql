DECLARE @TableName varchar(50) = 'dbo.Layout';

PRINT 'Create table ' + @TableName;
IF NOT EXISTS ( SELECT
                  1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                  AND TABLE_NAME = 'Layout' )
  BEGIN
    CREATE TABLE dbo.Layout (
      Layout_UID int IDENTITY(1,1),
      [Name] nvarchar(50) NOT NULL
        CONSTRAINT DF_Layout_Name
          DEFAULT (''),
      CONSTRAINT PK_Layout
        PRIMARY KEY ( Layout_UID )
    );
    PRINT 'Done.';
  END
ELSE
  PRINT 'The table already exists.';
