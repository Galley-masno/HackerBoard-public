DECLARE @TableName varchar(50) = 'dbo.Lesson';

PRINT 'Create table ' + @TableName;
IF NOT EXISTS ( SELECT
                  1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                  AND TABLE_NAME = 'Lesson' )
  BEGIN
    CREATE TABLE dbo.Lesson (
      Lesson_UID int IDENTITY(1,1),
      Title nvarchar(50) NOT NULL
        CONSTRAINT DF_Lesson_Title
          DEFAULT (''),
      [Description] nvarchar (150)
        CONSTRAINT DF_Lesson_Description
          DEFAULT (''),
      CourseFID int NOT NULL,
      CONSTRAINT PK_Lesson
        PRIMARY KEY ( Lesson_UID ),
      CONSTRAINT FK_Lesson_Course
        FOREIGN KEY ( CourseFID )
          REFERENCES dbo.Course ( Course_UID )
          ON DELETE CASCADE
    );
    PRINT 'Done.';
  END
ELSE
  PRINT 'The table already exists.';

