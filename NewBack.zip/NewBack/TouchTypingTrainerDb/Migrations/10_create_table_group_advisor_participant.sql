DECLARE @TableName varchar(50) = 'dbo.GroupAdvisorParticipant';

PRINT 'Create table ' + @TableName;
IF NOT EXISTS ( SELECT
                  1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                  AND TABLE_NAME = 'GroupAdvisorParticipant' )
  BEGIN
    CREATE TABLE dbo.GroupAdvisorParticipant (
      GroupAdvisorParticipant_UID int IDENTITY(1,1),
      AdvisorUserFID nvarchar(450) NOT NULL,
      ParticipantUserFID nvarchar(450) NOT NULL,
      GroupFID int NOT NULL,
      CONSTRAINT PK_GroupAdvisorParticipant
        PRIMARY KEY ( GroupAdvisorParticipant_UID ),
      CONSTRAINT FK_GroupAdvisorParticipant_UserAdvisor
        FOREIGN KEY ( AdvisorUserFID )
          REFERENCES dbo.AspNetUsers ( Id ),
      CONSTRAINT FK_GroupAdvisorParticipant_UserParticipant
        FOREIGN KEY ( ParticipantUserFID )
          REFERENCES dbo.AspNetUsers ( Id ),
      CONSTRAINT FK_GroupAdvisorParticipant_Group
        FOREIGN KEY ( GroupFID )
          REFERENCES dbo.[Group] ( Group_UID )
          ON DELETE CASCADE,
      CONSTRAINT CK_AdvisorNotParticipant
        CHECK (AdvisorUserFID <> ParticipantUserFID)
    );
    PRINT 'Done.';
  END
ELSE
  PRINT 'The table already exists.';