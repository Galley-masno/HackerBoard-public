DECLARE @TableName varchar(50) = 'dbo.LayoutKeys';

PRINT 'Create table ' + @TableName;
IF NOT EXISTS ( SELECT
                  1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                  AND TABLE_NAME = 'LayoutKeys' )
  BEGIN
    CREATE TABLE dbo.LayoutKeys (
      LayoutKeys_UID int IDENTITY(1,1),
      [Value] nchar(1) NOT NULL
        CONSTRAINT DF_LayoutKeys_Value
          DEFAULT (''),
      ShiftValue nchar(1) NOT NULL
        CONSTRAINT DF_LayoutKeys_ShiftValue
          DEFAULT (''),
      KeyFID int NOT NULL,
      LayoutFID int NOT NULL,
      CONSTRAINT PK_LayoutKeys
        PRIMARY KEY ( LayoutKeys_UID ),
      CONSTRAINT FK_LayoutKeys_Key
        FOREIGN KEY ( KeyFID )
          REFERENCES dbo.[Key] ( Position ),
      CONSTRAINT FK_LayoutKeys_Layout
        FOREIGN KEY ( LayoutFID )
          REFERENCES dbo.Layout ( Layout_UID )
    );
    PRINT 'Done.';
  END
ELSE
  PRINT 'The table already exists.';
