DECLARE @TableName varchar(50) = 'dbo.Course';

PRINT 'Create table ' + @TableName;
IF NOT EXISTS ( SELECT
                  1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                  AND TABLE_NAME = 'Course' )
  BEGIN
    CREATE TABLE dbo.Course (
      Course_UID int IDENTITY(1,1),
      Title nvarchar(50) NOT NULL
        CONSTRAINT DF_Course_Title
          DEFAULT (''),
      [Description] nvarchar(150) NOT NULL
        CONSTRAINT DF_Course_Description
          DEFAULT (''),
      LayoutFID int NOT NULL,
      CONSTRAINT PK_Course
        PRIMARY KEY ( Course_UID ),
      CONSTRAINT FK_Course_Layout
        FOREIGN KEY ( LayoutFID )
          REFERENCES dbo.Layout ( Layout_UID )
    );
    PRINT 'Done.';
  END
ELSE
  PRINT 'The table already exists.';
