DECLARE @TableName varchar(50) = 'dbo.[Group]';

PRINT 'Create table ' + @TableName;
IF NOT EXISTS ( SELECT
                  1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                  AND TABLE_NAME = 'Group' )
  BEGIN
    CREATE TABLE dbo.[Group] (
      Group_UID int IDENTITY(1,1),
      [Name] nvarchar(100) NOT NULL
        CONSTRAINT DF_Group_Name
          DEFAULT (''),
      CONSTRAINT PK_Group
        PRIMARY KEY ( Group_UID )
    );
    PRINT 'Done.';
  END
ELSE
  PRINT 'The table already exists.';
