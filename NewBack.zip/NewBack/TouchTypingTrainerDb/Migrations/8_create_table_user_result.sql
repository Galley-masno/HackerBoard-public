DECLARE @TableName varchar(50) = 'dbo.UserResult';

PRINT 'Create table ' + @TableName;
IF NOT EXISTS ( SELECT
                  1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                  AND TABLE_NAME = 'UserResult' )
  BEGIN
    CREATE TABLE dbo.UserResult (
      UserResult_UID int IDENTITY(1,1),
      Accuracy real NOT NULL
        CONSTRAINT DF_UserResult_Accuracy
          DEFAULT (0.0),
      Speed int NOT NULL
        CONSTRAINT DF_UserResult_Speed
          DEFAULT (0),
      ResultType tinyint NOT NULL -- 0-exercise, 1-testing material
        CONSTRAINT DF_UserResult_ResultType
          DEFAULT (0),
      CreatedAt date NOT NULL
        CONSTRAINT DF_TestingMaterial_CreatedAt
          DEFAULT getdate(),
      UserFID nvarchar(450) NOT NULL,
      TestingMaterialFID int,
      ExerciseFID int,
      CONSTRAINT PK_UserResult
        PRIMARY KEY ( UserResult_UID ),
      CONSTRAINT FK_UserResult_User
        FOREIGN KEY ( UserFID )
          REFERENCES dbo.AspNetUsers ( Id ),
      CONSTRAINT FK_UserResult_TestingMaterial
        FOREIGN KEY ( TestingMaterialFID )
          REFERENCES dbo.TestingMaterial ( TestingMaterial_UID ),
      CONSTRAINT FK_UserResult_Exercise
        FOREIGN KEY ( ExerciseFID )
          REFERENCES dbo.Exercise ( Exercise_UID ),
      CONSTRAINT CK_OneResultForeignKeyNotNull
        CHECK (TestingMaterialFID IS NOT NULL
          OR ExerciseFID IS NOT NULL)
    );
    PRINT 'Done.';
  END
ELSE
  PRINT 'The table already exists.';
