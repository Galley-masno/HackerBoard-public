DECLARE @TableName varchar(50) = 'dbo.UserCourseProgress';

PRINT 'Create table ' + @TableName;
IF NOT EXISTS ( SELECT
                  1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                  AND TABLE_NAME = 'UserCourseProgress' )
  BEGIN
    CREATE TABLE dbo.UserCourseProgress (
      UserCourseProgress_UID int IDENTITY(1,1),
      IsCompleted bit NOT NULL
        CONSTRAINT DF_UserCourseProgress_IsCompleted
          DEFAULT (0),
      CurrentExerciseFID int NOT NULL,
      CurrentLessonFID int NOT NULL,
      CourseFID int NOT NULL,
      UserFID nvarchar(450) NOT NULL,
      CONSTRAINT PK_UserCourseProgress
        PRIMARY KEY ( UserCourseProgress_UID ),
      CONSTRAINT FK_UserCourseProgress_Exercise
        FOREIGN KEY ( CurrentExerciseFID )
          REFERENCES dbo.Exercise ( Exercise_UID ),
      CONSTRAINT FK_UserCourseProgress_Lesson
        FOREIGN KEY ( CurrentLessonFID )
          REFERENCES dbo.Lesson ( Lesson_UID ),
      CONSTRAINT FK_UserCourseProgress_Course
        FOREIGN KEY ( CourseFID )
          REFERENCES dbo.Course ( Course_UID ),
      CONSTRAINT FK_UserCourseProgress_User
        FOREIGN KEY ( UserFID )
          REFERENCES dbo.AspNetUsers ( Id )
    );
    PRINT 'Done.';
  END
ELSE
  PRINT 'The table already exists.';
