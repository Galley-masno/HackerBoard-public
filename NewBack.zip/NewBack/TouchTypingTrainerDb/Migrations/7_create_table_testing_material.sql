DECLARE @TableName varchar(50) = 'dbo.TestingMaterial';

PRINT 'Create table ' + @TableName;
IF NOT EXISTS ( SELECT
                  1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                  AND TABLE_NAME = 'TestingMaterial' )
  BEGIN
    CREATE TABLE dbo.TestingMaterial (
      TestingMaterial_UID int IDENTITY(1,1),
      [Text] nvarchar(max) NOT NULL
        CONSTRAINT DF_TestingMaterial_Text
          DEFAULT (''),
      LayoutFID int NOT NULL,
      CONSTRAINT PK_TestingMaterial
        PRIMARY KEY ( TestingMaterial_UID ),
      CONSTRAINT FK_TestingMaterial_Layout
        FOREIGN KEY ( LayoutFID )
          REFERENCES dbo.Layout ( Layout_UID )
    );
    PRINT 'Done.';
  END
ELSE
  PRINT 'The table already exists.';
