ALTER TABLE dbo.Course
  ADD CONSTRAINT PK_Course
    PRIMARY KEY ( Course_UID );

ALTER TABLE dbo.Lesson
  ADD CONSTRAINT PK_Lesson
    PRIMARY KEY ( Lesson_UID );

ALTER TABLE dbo.Exercise
  ADD CONSTRAINT PK_Exercise
    PRIMARY KEY ( Exercise_UID );

ALTER TABLE dbo.TestingMaterial
  ADD CONSTRAINT PK_TestingMaterial
    PRIMARY KEY ( TestingMaterial_UID );

ALTER TABLE dbo.UserResult
  ADD CONSTRAINT PK_UserResult
    PRIMARY KEY ( UserResult_UID );

ALTER TABLE dbo.[Group]
  ADD CONSTRAINT PK_Group
    PRIMARY KEY ( Group_UID );

ALTER TABLE dbo.GroupAdvisorParticipant
  ADD CONSTRAINT PK_GroulAdvisorParticipant
    PRIMARY KEY ( GroupAdvisorParticipant_UID );

ALTER TABLE dbo.UserCourseProgress
  ADD CONSTRAINT PK_UserCourseProgress
    PRIMARY KEY ( UserCourseProgress_UID );

ALTER TABLE dbo.Lesson
  ADD CONSTRAINT FK_Lesson_Course
    FOREIGN KEY ( CourseFID )
      REFERENCES dbo.Course ( Course_UID )
      ON DELETE CASCADE;

ALTER TABLE dbo.Exercise
  ADD CONSTRAINT FK_Exercise_Lesson
    FOREIGN KEY ( LessonFID )
      REFERENCES dbo.Lesson ( Lesson_UID )
      ON DELETE CASCADE;

ALTER TABLE dbo.UserResult
  ADD CONSTRAINT FK_UserResult_User
    FOREIGN KEY ( UserFID )
      REFERENCES dbo.AspNetUsers ( Id );

ALTER TABLE dbo.UserResult
  ADD CONSTRAINT FK_UserResult_TestingMaterial
    FOREIGN KEY ( TestingMaterialFID )
      REFERENCES dbo.TestingMaterial ( TestingMaterial_UID );

ALTER TABLE dbo.UserResult
  ADD CONSTRAINT FK_UserResult_Exercise
    FOREIGN KEY ( ExerciseFID )
      REFERENCES dbo.Exercise ( Exercise_UID );

ALTER TABLE dbo.UserCourseProgress
  ADD CONSTRAINT FK_UserCourseProgress_Exercise
    FOREIGN KEY ( CurrentExerciseFID )
      REFERENCES dbo.Exercise ( Exercise_UID );

ALTER TABLE dbo.UserCourseProgress
  ADD CONSTRAINT FK_UserCourseProgress_Lesson
    FOREIGN KEY ( CurrentLessonFID )
      REFERENCES dbo.Lesson ( Lesson_UID );

ALTER TABLE dbo.UserCourseProgress
  ADD CONSTRAINT FK_UserCourseProgress_Course
    FOREIGN KEY ( CourseFID )
      REFERENCES dbo.Course ( Course_UID );

ALTER TABLE dbo.UserCourseProgress
  ADD CONSTRAINT FK_UserCourseProgress_User
    FOREIGN KEY ( UserFID )
      REFERENCES dbo.AspNetUsers ( Id );

ALTER TABLE dbo.GroupAdvisorParticipant
  ADD CONSTRAINT FK_GroupAdvisorParticipant_UserAdvisor
    FOREIGN KEY ( AdvisorUserFID )
      REFERENCES dbo.AspNetUsers ( Id );

ALTER TABLE dbo.GroupAdvisorParticipant
  ADD CONSTRAINT FK_GroupAdvisorParticipant_UserParticipant
    FOREIGN KEY ( ParticipantUserFID )
      REFERENCES dbo.AspNetUsers ( Id );

ALTER TABLE dbo.GroupAdvisorParticipant
  ADD CONSTRAINT FK_GroupAdvisorParticipant_Group
    FOREIGN KEY ( GroupFID )
      REFERENCES dbo.[Group] ( Group_UID )
      ON DELETE CASCADE;

ALTER TABLE dbo.[Key]
  ADD CONSTRAINT PK_Key
    PRIMARY KEY ( Position );

ALTER TABLE dbo.Layout
  ADD CONSTRAINT PK_Layout
    PRIMARY KEY ( Layout_UID );

ALTER TABLE dbo.LayoutKeys
  ADD CONSTRAINT PK_LayoutKeys
    PRIMARY KEY ( LayoutKeys_UID );

ALTER TABLE dbo.LayoutKeys
  ADD CONSTRAINT FK_LayoutKeys_Key
    FOREIGN KEY ( KeyFID )
      REFERENCES dbo.[Key] ( Position );

ALTER TABLE dbo.LayoutKeys
  ADD CONSTRAINT FK_LayoutKeys_Layout
    FOREIGN KEY ( LayoutFID )
      REFERENCES dbo.Layout ( Layout_UID );

ALTER TABLE dbo.TestingMaterial
  ADD CONSTRAINT FK_TestingMaterial_Layout
    FOREIGN KEY ( LayoutFID )
      REFERENCES dbo.Layout ( Layout_UID );

ALTER TABLE dbo.Course
  ADD CONSTRAINT FK_Course_Layout
    FOREIGN KEY ( LayoutFID )
      REFERENCES dbo.Layout ( Layout_UID );
