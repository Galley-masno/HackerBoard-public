import { Link } from "react-router-dom";
import "./TopBar.scss";

function TopBar() {
    return (
        <div id="TopBar">
            <Link to="/test">Тестування</Link>
            <Link to="/training">Тренажер</Link>
            <Link to="/"><div className="Circle"><svg src="Person.svg" className="PersonIcon"/></div></Link>
        </div>

    );

}

export default TopBar;