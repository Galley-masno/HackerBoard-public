// Login.js
import React, { useState} from 'react';
import { Link } from "react-router-dom";
import BaseUrl from '../../Global/BaseUrl';
import './Login.scss';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`${BaseUrl}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }), // Змінив login на email
      });

      if (!response.ok) {
        throw new Error('User not found');
      }

      const token = await response.text();
      localStorage.setItem('token', token); // Збереження токена в Local Storage
      setError('');
      window.history.back();
      // Перенаправлення або виконання інших дій після успішного логіну
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleLogin}>
        <h2>Вхід</h2>
        <div className="input-group">
          {/* <label>Логін:</label> */}
          <input 
            type="email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            required 
            placeholder='Email'
          />
        </div>
        <div className="input-group">
          {/* <label>Пароль:</label> */}
          <input 
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            required 
            placeholder='Пароль'
          />
        </div>
        <button type="submit" className="login-button">Enter</button>
        <Link to="/register">Нема акаунту? Жми тут, щоб зареєструватись</Link>
      </form>
      {error && <p className="error-message">{error}</p>}
    </div>
  );
};

export default Login;
