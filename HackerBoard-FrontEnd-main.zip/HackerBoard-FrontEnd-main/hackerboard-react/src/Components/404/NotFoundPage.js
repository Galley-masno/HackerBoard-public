import "./404.scss"
import { useNavigate } from "react-router-dom";

function NotFoundPage(){

    const navigate = useNavigate();

    const handleNavigation = () => {
        navigate('/');
    };

    return(
        <div id="NotFoundPage">
            <div div id="container404">
                <h1>404</h1>
                <p>Виглядаєш самотньо, я можу це виправити. Бажаєш повернутись на головну?</p>
                <button onClick={handleNavigation}>Так</button>
            </div>
        </div>
    );
}

export default NotFoundPage;