import React, { useState } from 'react';
import BaseUrl from '../../Global/BaseUrl';
import '../LoginPage/Login.scss'; 

const Register = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');

  const handleRegister = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError('Паролі не співпадають');
      return;
    }

    try {
      const response = await fetch(`${BaseUrl}/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }), // Змінив login на email
      });

      if (!response.ok) {
        throw new Error('Registration failed');
      }

      const data = await response.json();
      setError('');
      // Перенаправлення або виконання інших дій після успішної реєстрації
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleRegister}>
        <h2>Реєстрація</h2>
        <div className="input-group">
          <input 
            type="email" 
            value={email} // Змінив login на email
            onChange={(e) => setEmail(e.target.value)} // Змінив login на email
            required
            placeholder='Email' 
          />
        </div>
        <div className="input-group"> 
          <input 
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            required 
            placeholder='Пароль' 
          />
        </div>
        <div className="input-group">
          <input 
            type="password" 
            value={confirmPassword} 
            onChange={(e) => setConfirmPassword(e.target.value)} 
            required 
            placeholder='Підтвердіть пароль' 
          />
        </div>
        <button type="submit" className="login-button">Enter</button>
      </form>
      {error && <p className="error-message">{error}</p>}
    </div>
  );
};

export default Register;
