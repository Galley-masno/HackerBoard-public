import { useState } from "react";
import "./TextBar.scss";
import TextDataHandler from "./TextDataHandler";

function DumbTextBar({ purpose, number, onComplete }) {
    const [isShown, setIsShown] = useState(false);
    const [disableEffects, setDisableEffects] = useState("");

    const handleClick = () => {
        console.log("TextBar clicked"); // Додано для налагодження
        setIsShown(true);
        setDisableEffects("noEffects");
    };

    return (
        <div 
            id={ purpose === 'test' ? 'textBar' : 
                purpose === 'training' ? 'textBar-training' : 'textBar' 
            } 
            onClick={handleClick} 
            className={disableEffects} 
            tabIndex="0"
        >
            {!isShown && (
                <p id="startText">
                    Натисни тут щоб почати    
                </p>
            )}

            {isShown && (
                <div id="TextHandlerPTraining">
                    <TextDataHandler purpose={purpose} number={number} onComplete={onComplete} />
                </div>
            )}
        </div>
    );
}

export default DumbTextBar;
