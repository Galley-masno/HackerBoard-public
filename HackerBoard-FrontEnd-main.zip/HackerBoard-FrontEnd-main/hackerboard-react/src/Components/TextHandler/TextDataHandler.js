import { useEffect, useState } from "react";
import TextHandler from "./TextHandler";
import BaseUrl from "../../Global/BaseUrl";

const TextDataHandler = ({ purpose, number, onComplete }) => {
    const [exercise, setExercise] = useState(null);
    const [test, setTest] = useState(null);

    useEffect(() => {
        const fetchTextData = async () => {
            try {
                const token = localStorage.getItem('token');

                if (!token) {
                    console.error('No token found, please log in.');
                    return;
                }

                let response;
                const headers = {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                };

                let url;
                if (purpose === "test") {
                    url = `${BaseUrl}/typing-test/initialize`;
                } else if (purpose === "training") {
                    url = number ? 
                        `${BaseUrl}/typing-tutorial/initialize?exerciseId=${number}` : 
                        `${BaseUrl}/typing-tutorial/initialize`;
                } else {
                    console.error(`Invalid text data handler purpose type: ${purpose}. It should be 'test' or 'training`);
                    setExercise(null);
                    setTest(null);
                    return;
                }

                response = await fetch(url, {
                    method: 'GET',
                    headers: headers
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const data = await response.json();

                if (purpose === "test") {
                    if (data && data.text) {
                        setTest({
                            Id: data.id,
                            Text: data.text
                        });
                    } else {
                        console.error("Invalid test data format");
                        setTest(null);
                    }
                } else if (purpose === "training") {
                    if (data && data.studySet) {
                        setExercise({
                            Id: data.id || number,
                            Name: data.name || 'Training Exercise',
                            StudySet: data.studySet,
                            LessonId: data.lessonId || 0
                        });
                    } else {
                        console.error("Invalid training data format");
                        console.log("Received data: ", data);
                        setExercise(null);
                    }
                }
            } catch (error) {
                console.error('Failed to fetch text data:', error);
                setExercise(null);
                setTest(null);
            }
        };

        fetchTextData();
    }, [purpose, number]);

    return (
        <div>
            {purpose === "test" ? (
                test ? (
                    <TextHandler test={test} onComplete={onComplete} />
                ) : (
                    <p>Loading...</p>
                )
            ) : (
                exercise ? (
                    <TextHandler exercise={exercise} onComplete={onComplete} />
                ) : (
                    <p>Loading...</p>
                )
            )}
        </div>
    );
}

export default TextDataHandler;
