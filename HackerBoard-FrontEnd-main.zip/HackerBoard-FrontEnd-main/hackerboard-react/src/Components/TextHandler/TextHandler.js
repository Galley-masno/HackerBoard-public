import { useEffect, useRef, useState } from "react";
import BaseUrl from "../../Global/BaseUrl";

function TextHandler({ exercise, test, onComplete }) {
    const [typedText, setTypedText] = useState('');
    const [errorIndex, setErrorIndex] = useState(null);
    const [elapsedTime, setElapsedTime] = useState(0);
    const [isTypingStarted, setIsTypingStarted] = useState(false);
    const [isCompleted, setIsCompleted] = useState(false);
    const [speed, setSpeed] = useState(0);
    const [accuracy, setAccuracy] = useState(0);

    const nextCharR = useRef('');
    const mistakesCount = useRef(0);
    const timerRef = useRef(null);

    const initialText = exercise ? exercise.StudySet : (test ? test.Text : '');

    useEffect(() => {
        console.log("initialText:", initialText); // Додано для налагодження

        if (isCompleted) return;

        const handleKeyPress = (event) => {
            const char = event.key;
            const nextChar = initialText.charAt(typedText.length);
            nextCharR.current = nextChar;

            if (!isTypingStarted) {
                setIsTypingStarted(true);
                timerRef.current = setInterval(() => {
                    setElapsedTime(prevTime => prevTime + 1);
                }, 1000);
            }

            if (char === nextChar) {
                setTypedText(prevText => {
                    const newText = prevText + char;
                    if (newText.length === initialText.length) {
                        setIsCompleted(true);
                    }
                    return newText;
                });
                setErrorIndex(null);
            } else {
                setErrorIndex(typedText.length);
                mistakesCount.current += 1;
            }
        };

        window.addEventListener('keypress', handleKeyPress);
        return () => {
            window.removeEventListener('keypress', handleKeyPress);
        };
    }, [initialText, typedText, isCompleted, isTypingStarted]);

    useEffect(() => {
        if (isCompleted) {
            clearInterval(timerRef.current);
            sendCompletionData();
        }
    }, [isCompleted]);

    const sendCompletionData = async () => {
        try {
            const token = localStorage.getItem('token');
            const url = exercise ? `${BaseUrl}/typing-tutorial/completed` : `${BaseUrl}/typing-test/completed`;

            const headers = {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            };

            const completionData = exercise ? {
                ExerciseId: Number(exercise.Id),
                LessonId: Number(exercise.LessonId),
                Resource: typedText,
                MistakesCount: mistakesCount.current,
                Time: elapsedTime
            } : {
                TestId: Number(test.Id),
                Resource: typedText,
                MistakesCount: mistakesCount.current,
                Time: elapsedTime
            };

            const response = await fetch(url, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(completionData)
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Failed to send completion data: ${response.status} ${response.statusText} - ${errorText}`);
            }

            const responseData = await response.json();
            setAccuracy(responseData.accuracy);
            setSpeed(responseData.speed);

            if (onComplete) {
                onComplete(responseData.speed, responseData.accuracy);
            }
        } catch (error) {
            console.error('Error sending completion data:', error);
        }
    };

    return (
        <div>
            <div>
                {initialText.split("").map((char, index) => (
                    <span
                        key={index}
                        className={
                            typedText.charAt(index) === char ? 'doneText' :
                                index === errorIndex ? 'wrongText' : ''
                        }
                        style={{
                            backgroundColor: nextCharR.current === " " &&
                                index === errorIndex ? '#C90739' : 'transparent'
                        }}
                    >
                        {char}
                    </span>
                ))}
            </div>
            {/* {isCompleted && (
                <div>
                    <p>Швидкість: {speed} s/m</p>
                    <p>Точність: {accuracy}%</p>
                </div>
            )} */}
        </div>
    );
}

export default TextHandler;
