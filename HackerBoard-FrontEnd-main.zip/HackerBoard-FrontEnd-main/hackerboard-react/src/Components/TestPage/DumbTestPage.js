import "./Test.scss";
import TopBar from "../TopBar/TopBar";
import DumbTextBar from "../TextHandler/DumbTextBar"

function DumbTestPage(){

    return(
        <div id="TestPage">
            <TopBar />
            <DumbTextBar purpose="test"/>
        </div>
    )
}

export default DumbTestPage;