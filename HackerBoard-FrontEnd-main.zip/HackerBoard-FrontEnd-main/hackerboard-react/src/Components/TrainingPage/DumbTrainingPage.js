import "./Training.scss";
import TopBar from "../TopBar/TopBar";
import DumbTextBar from "../TextHandler/DumbTextBar";
import SmartChoose from "./Choose/SmartChoose";
import DumbResult from "../ResultHandler/DumbResult";

import { useState, useEffect } from "react";

function DumbTrainingPage() {
    const [exerciseNumber, setExerciseNumber] = useState(0);
    const [isChooseOpen, setIsChooseOpen] = useState(false);
    const [isResultPopUp, setIsResultPopUp] = useState(false);
    const [result, setResult] = useState(null);

    const exerciseNumberHandler = (number) => {
        setExerciseNumber(number);
        const queryParams = new URLSearchParams(window.location.search);
        queryParams.set('exerciseId', number.toString());
        window.history.replaceState({}, '', `${window.location.pathname}?${queryParams}`);
    }

    const toggleChoose = () => {
        setIsChooseOpen(!isChooseOpen);
    }

    const toggleResult = () => {
        setIsResultPopUp(!isResultPopUp);
    }

    useEffect(() => {
        const queryParams = new URLSearchParams(window.location.search);
        const exerciseId = queryParams.get('exerciseId');
        if (exerciseId !== null) {
            setExerciseNumber(parseInt(exerciseId));
        }
    }, []);

    const doStuff = (number) => {
        exerciseNumberHandler(number);
        toggleChoose();
    }

    const handleComplete = (speed, accuracy) => {
        setResult({ speed, accuracy });
        toggleResult();
    }

    return (
        <div id="TrainingPage">
            {!isChooseOpen && !isResultPopUp && <TopBar className="Training" />}
            {!isChooseOpen && !isResultPopUp && <DumbTextBar purpose="training" number={exerciseNumber} onComplete={handleComplete} />}
            {!isChooseOpen && !isResultPopUp && <div id="Toggle" onClick={toggleChoose}>Налаштування</div>}
            
            {isResultPopUp && <DumbResult onClick={toggleResult} resultSpeed={result?.speed} resultAccuracy={result?.accuracy} />}
            {isChooseOpen && <SmartChoose handlerFunction={doStuff} />}
        </div>
    );
}

export default DumbTrainingPage;
