import React from 'react';
import './Choose.scss';

const DumbChoose = ({ lessons, currentExerciseIdentifier, handlerFunction }) => {
  console.log('Received Current Exercise ID:', currentExerciseIdentifier);

  return (
    <div id="ChooseBar">
      {lessons.map((lesson) => (
        <div key={lesson.Id}>
          <h2>{lesson.Name}</h2>
          <p>{lesson.Description}</p>
          {lesson.Exercises.map((exercise) => (
            <div
              className={`ExerciseBar ${exercise.Id <= currentExerciseIdentifier ? '' : 'disabled'}`}
              onClick={() => exercise.Id <= currentExerciseIdentifier && handlerFunction(exercise.Id)}
              key={exercise.Id}
            >
              <label>{exercise.Name}</label>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

export default DumbChoose;
