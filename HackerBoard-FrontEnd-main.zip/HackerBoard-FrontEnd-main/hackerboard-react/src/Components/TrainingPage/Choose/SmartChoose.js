import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Choose.scss';
import DumbChoose from './DumbChoose';
import BaseUrl from '../../../Global/BaseUrl';

const SmartChoose = ({ handlerFunction }) => {
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentExerciseIdentifier, setCurrentExerciseIdentifier] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchLessonsAndCurrentExercise = async () => {
      const token = localStorage.getItem('token');

      if (!token) {
        setError('No token found, please log in.');
        setLoading(false);
        navigate('/login'); // Redirect to login page if no token is found
        return;
      }

      try {
        // Fetch lessons
        const lessonsResponse = await fetch(`${BaseUrl}/typing-tutorial/lessons`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });

        if (lessonsResponse.status === 401) {
          throw new Error('Unauthorized. Token might be invalid.');
        }

        if (!lessonsResponse.ok) {
          throw new Error('Failed to fetch lessons');
        }

        const lessonsData = await lessonsResponse.json();
        setLessons(lessonsData);
        setError('');

        // Fetch current exercise
        const currentExerciseResponse = await fetch(`${BaseUrl}/user/current-exercise`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });

        if (currentExerciseResponse.status === 401) {
          throw new Error('Unauthorized. Token might be invalid.');
        }

        if (!currentExerciseResponse.ok) {
          throw new Error('Failed to fetch current exercise');
        }

        const currentExerciseId = await currentExerciseResponse.json();
        setCurrentExerciseIdentifier(currentExerciseId);
        console.log('Current Exercise ID (smart):', currentExerciseId);

      } catch (error) {
        setError(error.message);
        if (error.message.includes('Unauthorized')) {
          navigate('/login'); // Redirect to login page if token is invalid
        }
      } finally {
        setLoading(false);
      }
    };

    fetchLessonsAndCurrentExercise();
  }, [navigate]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return <DumbChoose lessons={lessons} currentExerciseIdentifier={currentExerciseIdentifier} handlerFunction={handlerFunction} />;
};

export default SmartChoose;
