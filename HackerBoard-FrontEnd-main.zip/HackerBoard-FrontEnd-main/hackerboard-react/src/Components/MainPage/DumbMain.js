import TopBar from "../TopBar/TopBar";
import { useNavigate } from "react-router-dom";
import "./Main.scss";

function DumbMainPage(){
    const navigate = useNavigate();

    const handleNavigation = () => {
        navigate('/test');
    };

    return(
        <div id="MainPage">
            <TopBar/>
            <div id="textBox" className="d-flex align-items-center">
                <div id="container">
                    <h1 className="display-1" id="title">Хочеш стати таким же крутим хакером?</h1>
                    <p>Доєднюйся до HackerBoard та ставай справжнім майстром набору на клавіатурі</p>
                    <br/>
                    <button onClick={handleNavigation}>ПРОЙТИ ТЕСТ</button>
                </div>
            </div> 
        </div>
    );
    
}

export default DumbMainPage;