import { createContext } from 'react'
import './Result.scss';

const DumbResult = ({onClick, resultSpeed, resultAccuracy}) => {
    const handleClick = () => {
        console.log("DumbResult clicked"); // Додано для налагодження
        onClick();
    };

    return(
        <div id='back'>
            <div id='resultBar' onClick={onClick}>
                <p>Швидкість: {resultSpeed} с/х</p>
                <p>Точність: {resultAccuracy} %</p>
            </div>
        </div>
    );
}

export default DumbResult;