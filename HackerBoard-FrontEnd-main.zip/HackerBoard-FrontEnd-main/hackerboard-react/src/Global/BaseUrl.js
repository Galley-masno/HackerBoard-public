const BaseUrl = "https://localhost:7245/api";
export default BaseUrl; 