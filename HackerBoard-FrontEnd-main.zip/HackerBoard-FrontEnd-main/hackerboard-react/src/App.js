import { Route, Routes } from "react-router-dom";
import DumbMainPage from "./Components/MainPage/DumbMain.js";
import DumbTrainingPage from "./Components/TrainingPage/DumbTrainingPage.js";
import DumbTestPage from "./Components/TestPage/DumbTestPage.js";
import NotFoundPage from "./Components/404/NotFoundPage.js";
import Login from "./Components/LoginPage/Login.js";
import Register from "./Components/RegistrationPage/Register.js";

function App() {
  return (
    <Routes>
      <Route path="/" element={<DumbMainPage />} />
      <Route path="/training" element={<DumbTrainingPage />} />
      <Route path="/test" element={<DumbTestPage />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="*" element={<NotFoundPage />} />
    </Routes>

  );
}

export default App;
