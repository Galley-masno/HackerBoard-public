﻿using KeyboardMasterBackend.Models.Entityes;
using KeyboardMasterBackend.Models.Wrappers;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace KeyboardMasterBackend.Data
{
    public class UserDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<TestingMaterial> TestingMaterials { get; set; }
        public DbSet<Lesson> Lessons { get; set; }
        public DbSet<Exercise> Exercises { get; set; }
        public DbSet<LearningResult> LearningResults { get; set; }
        public DbSet<TestResult> TestResults { get; set; }


        public UserDbContext(DbContextOptions<UserDbContext> options)
            : base(options)
        { Database.EnsureCreated(); }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            var connectionString = configuration.GetConnectionString("Local");

            optionsBuilder.UseSqlServer(connectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            const string JSON_FILE_PATH = "./data.json";
            var jsonData = File.ReadAllText(JSON_FILE_PATH);

            var data = JsonSerializer.Deserialize<DataSeed>(jsonData);

            modelBuilder.Entity<Exercise>().HasData(data.Exercises);
            modelBuilder.Entity<LearningResult>().HasData(data.LearningResults);
            modelBuilder.Entity<Lesson>().HasData(data.Lessons);
            modelBuilder.Entity<TestingMaterial>().HasData(data.TestingMaterials);
            modelBuilder.Entity<TestResult>().HasData(data.TestResults);
            modelBuilder.Entity<User>().HasData(data.Users);
        }
    }
}
