﻿namespace KeyboardMasterBackend.Services.SerializationServices
{
    public interface IJsonSerializationService
    {
        string SerializeWithoutReference(object value);
    }
}
