﻿using Newtonsoft.Json;

namespace KeyboardMasterBackend.Services.SerializationServices
{
    public class JsonSerializationService : IJsonSerializationService
    {
        public string SerializeWithoutReference(object value)
        {
            var settings = new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            };

            var serializedObject = JsonConvert.SerializeObject(value, settings);

            return serializedObject;
        }
    }
}
