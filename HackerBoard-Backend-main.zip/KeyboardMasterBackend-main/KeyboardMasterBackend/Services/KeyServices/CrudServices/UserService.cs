﻿using KeyboardMasterBackend.Data;
using KeyboardMasterBackend.Models.Entityes;
using KeyboardMasterBackend.Models.Responses;
using Microsoft.EntityFrameworkCore;

namespace KeyboardMasterBackend.Services.KeyServices.CrudServices
{
    public class UserService : CrudService, IUserService
    {
        public UserService(UserDbContext context)
            : base(context)
        {
        }

        public async Task<IEnumerable<ExerciseAvarageResult>> ExerciseAvarangeResultsAsync(int userId)
        {
            return await _context.LearningResults
                .Where(lr => lr.UserId == userId)
                .GroupBy(lr => lr.ExerciseId)
                .Select(g => new ExerciseAvarageResult
                {
                    ExerciseId = g.Key,
                    AverageAccuracy = g.Average(lr => lr.Accuracy),
                    AverageSpeed = g.Average(lr => lr.Speed)
                }).ToListAsync();
        }

        public async Task UpdateCurrentsAsync(int userId, int exerciseId, int lessonId)
        {
            User user = await UserAsync(userId);
            Exercise? previousEx = await FindPreviousExerciseAsync(exerciseId);

            if (previousEx != null)
            {
                if (user.CurrentExerciseId == previousEx.Id)
                {
                    user.CurrentExerciseId = exerciseId;
                    user.CurrentLessonId = lessonId;

                    _context.Users.Update(user);

                    await _context.SaveChangesAsync();
                }
            }
        }

        public async Task<User> UserAsync(int id)
        {
            return await _context.Users
                .SingleOrDefaultAsync(u => u.Id == id);
        }

        public async Task<Exercise?> FindPreviousExerciseAsync(int currentExid)
        {
            return await _context.Exercises
                .Where(e => e.Id < currentExid)
                .OrderByDescending(e => e.Id)
                .FirstOrDefaultAsync();
        }

        public async Task AddTestResultAsync(TestResult result)
        {
            await _context.TestResults.AddAsync(result);

            await _context.SaveChangesAsync();
        }

        public async Task AddLearningResultAsync(LearningResult result)
        {
            await _context.LearningResults.AddAsync(result);

            await _context.SaveChangesAsync();
        }

        public async Task<User> UserAsync(string email)
        {
            return await _context.Users
                .SingleOrDefaultAsync(u => u.Email == email);
        }

        public async Task<int> GetCurrentLessonIdAsync(int userId)
        {
            return await _context.Users
                .Where(u => u.Id == userId)
                .Select(u => u.CurrentLessonId)
                .SingleAsync(); 
        }

        public async Task<int> GetCurrentExerciseIdAsync(int userId)
        {
            return await _context.Users
                .Where(u => u.Id == userId)
                .Select(u => u.CurrentExerciseId)
                .SingleAsync();
        }
    }
}
