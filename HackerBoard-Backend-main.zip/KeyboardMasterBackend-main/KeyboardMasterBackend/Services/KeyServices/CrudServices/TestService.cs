﻿using KeyboardMasterBackend.Data;
using KeyboardMasterBackend.Models.Entityes;
using Microsoft.EntityFrameworkCore;

namespace KeyboardMasterBackend.Services.KeyServices.CrudServices
{
    public class TestService : CrudService, ITestService
    {
        public TestService(UserDbContext context)
            : base(context)
        {
        }

        public async Task<TestingMaterial?> GetRandomTestSetAsync()
        {
            int count = await _context.TestingMaterials
                .CountAsync();

            if (count == 0)
                return null;

            var random = new Random();

            int skip = random.Next(count);

            return await _context.TestingMaterials
                .Skip(skip)
                .FirstOrDefaultAsync();
        }
    }
}
