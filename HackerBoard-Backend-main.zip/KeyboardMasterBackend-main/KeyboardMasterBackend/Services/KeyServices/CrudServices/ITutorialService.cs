﻿using KeyboardMasterBackend.Models.Entityes;
using KeyboardMasterBackend.Models.Responses;

namespace KeyboardMasterBackend.Services.KeyServices.CrudServices
{
    public interface ITutorialService
    {
        Task<IEnumerable<Lesson>> LessonsAsync(); 
        Task<Exercise> ExerciseAsync(int? id); 
        Task<DefaultExercise> DefaultSetAsync(); 
    }
}
