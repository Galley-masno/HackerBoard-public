﻿using KeyboardMasterBackend.Data;
using KeyboardMasterBackend.Models.Entityes;
using KeyboardMasterBackend.Models.Responses;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace KeyboardMasterBackend.Services.KeyServices.CrudServices
{
    public class TutorialService : CrudService, ITutorialService
    {
        public TutorialService(UserDbContext context) 
            : base(context)
        {
        }

        public async Task<DefaultExercise> DefaultSetAsync()
        {
            const string JSON_FILE_PATH = "./data.json";
            var json = await File.ReadAllTextAsync(JSON_FILE_PATH);

            return JsonConvert.DeserializeObject<DefaultExercise>(json);
        }

        public async Task<Exercise> ExerciseAsync(int? id)
        {
            return await _context.Exercises
                .SingleAsync(e => e.Id == id);
        }

        public async Task<IEnumerable<Lesson>> LessonsAsync()
        {
            return await _context.Lessons
                .Include(l => l.Exercises)
                .ToListAsync();
        }
    }
}
