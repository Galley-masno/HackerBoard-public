﻿using KeyboardMasterBackend.Models.Entityes;

namespace KeyboardMasterBackend.Services.KeyServices.CrudServices
{
    public interface ITestService
    {
        Task<TestingMaterial?> GetRandomTestSetAsync();
    }
}
