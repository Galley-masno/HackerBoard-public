﻿using KeyboardMasterBackend.Models.Entityes;
using KeyboardMasterBackend.Models.Responses;
using Microsoft.EntityFrameworkCore;

namespace KeyboardMasterBackend.Services.KeyServices.CrudServices
{
    public interface IUserService
    {
        Task<User> UserAsync(int id);
        Task<User> UserAsync(string email);
        Task<IEnumerable<ExerciseAvarageResult>> ExerciseAvarangeResultsAsync(int userId);
        Task UpdateCurrentsAsync(int userId, int exerciseId, int lessonId);
        Task<Exercise?> FindPreviousExerciseAsync(int currentExid);
        Task AddTestResultAsync(TestResult result);
        Task AddLearningResultAsync(LearningResult result);
        Task<int> GetCurrentLessonIdAsync(int userId);
        Task<int> GetCurrentExerciseIdAsync(int userId);
    }
}
