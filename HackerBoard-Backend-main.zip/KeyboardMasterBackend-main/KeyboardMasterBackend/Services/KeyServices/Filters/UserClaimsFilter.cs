﻿using KeyboardMasterBackend.Controllers;
using KeyboardMasterBackend.Models;
using KeyboardMasterBackend.Services.AuthorizationServices;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace KeyboardMasterBackend.Services.KeyServices.Filters
{
    public class UserClaimsFilter : IAsyncActionFilter
    {
        readonly private IJwtAuthorizationService _jwtAuthorizationService;

        public UserClaimsFilter(IJwtAuthorizationService jwtAuthorizationService)
        {
            _jwtAuthorizationService = jwtAuthorizationService;
        }

        [NonAction]
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var controller = context.Controller as TypingControllerBase;
            if (controller != null)
            {
                controller
                    .SetUserClaims(_jwtAuthorizationService
                    .GetCurrentUserClaims(context.HttpContext));
            }

            await next();
        }
    }
}
