﻿using KeyboardMasterBackend.Models.Requests;
using KeyboardMasterBackend.Models.Responses;

namespace KeyboardMasterBackend.Services.KeyServices.CalculationServices
{
    public class CalcPerformance : ICalcPerformance
    {
        public UserPerformance CalculateResult(ITypingCompleteRequest request)
        {
            int setsLength = request.Resource.Length;

            var performance = new UserPerformance()
            {
                Accuracy = (setsLength - request.MistakesCount) * 100 / setsLength,
                Speed = setsLength * 60 / request.Time
            };

            return performance;
        }
    }
}
