﻿using KeyboardMasterBackend.Models.Requests;
using KeyboardMasterBackend.Models.Responses;

namespace KeyboardMasterBackend.Services.KeyServices.CalculationServices
{
    public interface ICalcPerformance
    {
        UserPerformance CalculateResult(ITypingCompleteRequest request);
    }
}
