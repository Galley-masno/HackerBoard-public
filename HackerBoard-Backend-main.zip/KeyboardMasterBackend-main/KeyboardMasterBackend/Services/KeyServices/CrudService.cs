﻿using KeyboardMasterBackend.Data;

namespace KeyboardMasterBackend.Services.KeyServices
{
    public abstract class CrudService
    {
        readonly protected UserDbContext _context;

        public CrudService(UserDbContext context)
        {
            _context = context;
        }
    }
}
