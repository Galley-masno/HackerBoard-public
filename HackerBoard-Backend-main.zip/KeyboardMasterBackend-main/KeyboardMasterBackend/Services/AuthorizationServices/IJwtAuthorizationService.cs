﻿using KeyboardMasterBackend.Models.Entityes;

namespace KeyboardMasterBackend.Services.AuthorizationServices
{
    public interface IJwtAuthorizationService
    {
        User GetCurrentUserClaims(HttpContext context); 
        string GenerateToken(User user);
    }
}
