﻿using KeyboardMasterBackend.Data;
using KeyboardMasterBackend.Models.Entityes;
using Microsoft.EntityFrameworkCore;

namespace KeyboardMasterBackend.Services.AuthenticationServices
{
    public class AuthenticationService : IAuthenticationService
    {
        private readonly UserDbContext _context; 

        public AuthenticationService(UserDbContext context)
        {
            _context = context; 
        }

        public async Task<User> Authenticate(User userLogin)
        {
            return await _context.Users
                .FirstOrDefaultAsync(o => o.Email
                .ToLower() == userLogin.Email
                .ToLower() && o.Password == userLogin.Password);
        }

        public async Task Registrate(User user)
        {
            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync(); 
        }
    }
}
