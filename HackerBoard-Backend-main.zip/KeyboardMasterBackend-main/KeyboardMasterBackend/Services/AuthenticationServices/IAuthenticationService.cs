﻿using KeyboardMasterBackend.Models.Entityes;

namespace KeyboardMasterBackend.Services.AuthenticationServices
{
    public interface IAuthenticationService
    {
        Task<User> Authenticate(User userLogin);
        Task Registrate(User user);
    }
}
