﻿using KeyboardMasterBackend.Models.Entityes;

namespace KeyboardMasterBackend.Models.Wrappers
{
    public class DataSeed
    {
        public List<Exercise> Exercises { get; set; }
        public List<LearningResult> LearningResults { get; set; }
        public List<Lesson> Lessons { get; set; }
        public List<TestingMaterial> TestingMaterials { get; set; }
        public List<TestResult> TestResults { get; set; }
        public List<User> Users { get; set; }
    }
}
