using KeyboardMasterBackend.Models.Entityes;

namespace KeyboardMasterBackend.Models.Requests
{
    public class ExerciseCompleteRequest 
        : ITypingCompleteRequest
    {
        public int ExerciseId { get; set; }
        public int LessonId { get; set; }
        public string Resource { get; set; }
        public int MistakesCount { get; set; }
        public int Time { get; set; }
    }
}
