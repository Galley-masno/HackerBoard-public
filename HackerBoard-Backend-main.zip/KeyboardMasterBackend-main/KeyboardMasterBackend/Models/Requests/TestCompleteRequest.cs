﻿using KeyboardMasterBackend.Models.Entityes;

namespace KeyboardMasterBackend.Models.Requests
{
    public class TestCompleteRequest
        : ITypingCompleteRequest
    {
        public string Resource { get; set; }
        public int Time { get; set; }
        public int MistakesCount { get; set; }
    }
}
