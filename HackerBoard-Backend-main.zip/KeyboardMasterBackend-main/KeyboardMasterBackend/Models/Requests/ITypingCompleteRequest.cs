﻿namespace KeyboardMasterBackend.Models.Requests
{
    public interface ITypingCompleteRequest
    {
        string Resource { get; set; }
        int MistakesCount { get; set; }
        int Time { get; set; }
    }
}
