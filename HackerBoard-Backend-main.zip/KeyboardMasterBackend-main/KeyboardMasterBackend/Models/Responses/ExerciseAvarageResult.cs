﻿namespace KeyboardMasterBackend.Models.Responses
{
    public class ExerciseAvarageResult
    {
        public int ExerciseId { get; set; }
        public double AverageAccuracy { get; set; }
        public double AverageSpeed { get; set; }
    }
}
