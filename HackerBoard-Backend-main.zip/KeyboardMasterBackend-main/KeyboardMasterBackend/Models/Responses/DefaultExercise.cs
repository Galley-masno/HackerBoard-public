﻿namespace KeyboardMasterBackend.Models.Responses
{
    public class DefaultExercise
    {
        public string Text { get; set; }
    }
}
