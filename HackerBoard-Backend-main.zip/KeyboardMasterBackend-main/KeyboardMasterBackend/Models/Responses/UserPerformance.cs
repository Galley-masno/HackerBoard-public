namespace KeyboardMasterBackend.Models.Responses
{
    public class UserPerformance
    {
        public int Speed { get; set; }
        public int Accuracy { get; set; }
    }
}