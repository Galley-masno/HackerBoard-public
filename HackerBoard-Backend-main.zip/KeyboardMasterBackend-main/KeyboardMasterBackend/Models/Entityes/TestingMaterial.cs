﻿namespace KeyboardMasterBackend.Models.Entityes
{
    public class TestingMaterial
    {
        public int Id { get; set; }
        public string Text { get; set; }
    }
}
