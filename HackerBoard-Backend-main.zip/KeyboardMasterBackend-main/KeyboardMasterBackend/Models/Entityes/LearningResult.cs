﻿namespace KeyboardMasterBackend.Models.Entityes
{
    public class LearningResult
    {
        public int Id { get; set; }
        public int Accuracy { get; set; }
        public int Speed { get; set; }

        public int UserId { get; set; }
        public int ExerciseId { get; set; }
        public User User { get; set; }
        public Exercise Exercise { get; set; }
    }
}
