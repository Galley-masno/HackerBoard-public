﻿namespace KeyboardMasterBackend.Models.Entityes
{
    public class Exercise
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string StudySet { get; set; }

        public int LessonId { get; set; }
        public Lesson? Lesson { get; set; }
    }
}
