﻿namespace KeyboardMasterBackend.Models.Entityes
{
    public class User
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int CurrentLessonId { get; set; } = 1;
        public int CurrentExerciseId { get; set; } = 1;

        public ICollection<LearningResult>? LearningResults { get; set; }
        public ICollection<TestResult>? TestResults { get; set; }
    }
}
