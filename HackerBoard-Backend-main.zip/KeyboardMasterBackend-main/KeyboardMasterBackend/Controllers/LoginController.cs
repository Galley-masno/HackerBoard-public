﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using KeyboardMasterBackend.Services.AuthenticationServices;
using KeyboardMasterBackend.Services.AuthorizationServices;
using KeyboardMasterBackend.Models.Entityes;
using KeyboardMasterBackend.Services.KeyServices.CrudServices;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;

using IAuthenticationService = KeyboardMasterBackend.Services.AuthenticationServices.IAuthenticationService;

namespace KeyboardMasterBackend.Controllers
{
    [Route("api")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly IJwtAuthorizationService _jwtAuthorizationService;
        private readonly IUserService _userService;

        public LoginController(IAuthenticationService authenticationService,
            IJwtAuthorizationService jwtAuthorizationService,
            IUserService userService)
        {
            _authenticationService = authenticationService;
            _jwtAuthorizationService = jwtAuthorizationService;
            _userService = userService;
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] User userLogin)
        {
            var user = await _authenticationService.Authenticate(userLogin);

            if (user != null)
            {
                var token = _jwtAuthorizationService.GenerateToken(user);
                return Ok(token);
            }

            return NotFound("User not found");
        }

        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<IActionResult> Registration(User userRegistration)
        {
            var user = await _userService.UserAsync(userRegistration.Email);

            if (user is null)
            {
                await _authenticationService.Registrate(userRegistration);
                return Ok();
            }
            return BadRequest();
        }
    }
}
