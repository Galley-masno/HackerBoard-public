﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using KeyboardMasterBackend.Services.AuthorizationServices;
using KeyboardMasterBackend.Services.KeyServices.CrudServices;

namespace KeyboardMasterBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : TypingControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IJwtAuthorizationService jwtAuthorizationService, 
            IUserService userService) 
            : base(jwtAuthorizationService)
        {
            _userService = userService;
        }

        [Authorize]
        [HttpGet("current-exercise")]
        public async Task<int> GetCurrentExerciseId()
        {
            if (User.Identity.IsAuthenticated) 
            {
                if (_userClaims != null)
                    return await _userService.GetCurrentExerciseIdAsync(_userClaims.Id);
            }
            return 0; 
        }

        [Authorize]
        [HttpGet("current-lesson")]
        public async Task<int> GetCurrentLessonId()
        {
            if (User.Identity.IsAuthenticated)
            {
                if (_userClaims != null)
                    return await _userService.GetCurrentLessonIdAsync(_userClaims.Id);
            }
            return 0;
        }
    }
}
