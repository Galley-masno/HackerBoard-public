﻿using KeyboardMasterBackend.Services.AuthorizationServices;
using KeyboardMasterBackend.Services.SerializationServices;
using KeyboardMasterBackend.Services.KeyServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using KeyboardMasterBackend.Models.Entityes;
using KeyboardMasterBackend.Models.Requests;
using KeyboardMasterBackend.Models.Responses;
using KeyboardMasterBackend.Services.KeyServices.CalculationServices;
using KeyboardMasterBackend.Services.KeyServices.CrudServices;

namespace KeyboardMasterBackend.Controllers
{
    [Route("api/typing-tutorial")]
    [ApiController]
    public class TuturialController : TypingControllerBase
    {
        readonly private IJsonSerializationService _serializationService;
        readonly private ITutorialService _tutorialService;
        readonly private IUserService _userService; 
        readonly private ICalcPerformance _calcPerformance;

        public TuturialController(IJwtAuthorizationService jwtAuthorizationService,
            IJsonSerializationService serializationService,
            ITutorialService typingCrudService,
            ICalcPerformance calcPerformance,
            IUserService userService) 
          : base (jwtAuthorizationService)
        {
            _serializationService = serializationService;
            _tutorialService = typingCrudService;
            _calcPerformance = calcPerformance;
            _userService = userService;
        }

        [Authorize]
        [HttpGet("lessons")]
        public async Task<IActionResult> GetLessons()
        {
            var lessons = await _tutorialService.LessonsAsync(); 

            string json = _serializationService
                    .SerializeWithoutReference(lessons);

            return Ok(json);
        }

        [Authorize]
        [HttpGet("results")]
        public async Task<IActionResult> GetResults()
        {
            if (_userClaims != null)
            {
                var results = await _userService
                    .ExerciseAvarangeResultsAsync(_userClaims.Id);

                return Ok(results);
            }
            return BadRequest();
        }

        [HttpGet("initialize")]
        public async Task<IActionResult> Initialize(int? exerciseId)
        {
            if (HttpContext.User.Identity.IsAuthenticated)
            {
                if (_userClaims != null)
                {
                    User user = await _userService.UserAsync(_userClaims.Id);

                    var eId = exerciseId is not null && exerciseId <= user.CurrentExerciseId ?
                        exerciseId :
                        user.CurrentExerciseId;

                    var exercise = await _tutorialService.ExerciseAsync(eId);

                    return Ok(exercise);
                }
            }

            var defaultExerciseSet = await _tutorialService.DefaultSetAsync(); 

            return Ok(defaultExerciseSet);
        }

        [HttpPost("completed")]
        public async Task<IActionResult> ExerciseComplete(ExerciseCompleteRequest request)
        {
            UserPerformance result = _calcPerformance.CalculateResult(request);

            if (HttpContext.User.Identity.IsAuthenticated)
            {
                if (_userClaims != null)
                {
                    await _userService.UpdateCurrentsAsync(_userClaims.Id, request.ExerciseId, request.LessonId);

                    await _userService.AddLearningResultAsync(new LearningResult()
                    {
                        Accuracy = result.Accuracy,
                        Speed = result.Speed,
                        UserId = _userClaims.Id,
                        ExerciseId = request.ExerciseId
                    });
                }                
            }
            return Ok(result);
        }
    }
}
