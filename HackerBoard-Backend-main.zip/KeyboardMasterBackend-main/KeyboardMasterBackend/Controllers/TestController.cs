﻿using Microsoft.AspNetCore.Mvc;
using KeyboardMasterBackend.Services.AuthorizationServices;
using KeyboardMasterBackend.Models.Entityes;
using KeyboardMasterBackend.Models.Requests;
using KeyboardMasterBackend.Models.Responses;
using KeyboardMasterBackend.Services.KeyServices.CalculationServices;
using KeyboardMasterBackend.Services.KeyServices.CrudServices;

namespace KeyboardMasterBackend.Controllers
{
    [Route("api/typing-test")]
    [ApiController]
    public class TestController : TypingControllerBase
    {
        readonly private ICalcPerformance _calcPerformance;
        readonly private ITestService _testService;
        readonly private IUserService _userService;

        public TestController(IJwtAuthorizationService jwtAuthorizationService,
            ICalcPerformance calcPerformance,
            ITestService testService,
            IUserService userService)
            : base(jwtAuthorizationService)
        {
            _calcPerformance = calcPerformance;
            _testService = testService;
            _userService = userService;
        }

        [HttpGet("initialize")]
        public async Task<IActionResult> Initialize()
        {
            TestingMaterial? test = await _testService
                .GetRandomTestSetAsync();

            if (test == null) 
                return BadRequest(); 
            return Ok(test);
        }

        [HttpPost("completed")]
        public async Task<IActionResult> Complete(TestCompleteRequest request)
        {
            UserPerformance performance = _calcPerformance
                .CalculateResult(request);

            if (User.Identity.IsAuthenticated) 
            {
                if (_userClaims != null) 
                {
                    await _userService.AddTestResultAsync(new TestResult()
                    {
                        Accuracy = performance.Accuracy, 
                        Speed = performance.Speed,
                        UserId = _userClaims.Id
                    });
                }                
            }
            return Ok(performance); 
        }
    }
}