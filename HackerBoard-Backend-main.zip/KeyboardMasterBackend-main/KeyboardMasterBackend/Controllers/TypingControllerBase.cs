﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using KeyboardMasterBackend.Services.AuthorizationServices;
using Microsoft.AspNetCore.Mvc.Filters;
using KeyboardMasterBackend.Models.Entityes;

namespace KeyboardMasterBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TypingControllerBase : ControllerBase
    {
        readonly protected IJwtAuthorizationService _jwtAuthService;
        protected User? _userClaims;

        public TypingControllerBase(IJwtAuthorizationService jwtAuthorizationService)
        {
            _jwtAuthService = jwtAuthorizationService;
        }

        [NonAction]
        public void SetUserClaims(User userClaims)
        {
            _userClaims = userClaims;
        }
    }
}
