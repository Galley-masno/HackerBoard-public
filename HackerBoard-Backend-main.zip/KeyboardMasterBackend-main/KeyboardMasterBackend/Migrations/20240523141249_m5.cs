﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace KeyboardMasterBackend.Migrations
{
    /// <inheritdoc />
    public partial class m5 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_LearningResult_Exercises_ExerciseId",
                table: "LearningResult");

            migrationBuilder.DropForeignKey(
                name: "FK_LearningResult_Users_UserId",
                table: "LearningResult");

            migrationBuilder.DropForeignKey(
                name: "FK_TestResult_Users_UserId",
                table: "TestResult");

            migrationBuilder.DropPrimaryKey(
                name: "PK_TestResult",
                table: "TestResult");

            migrationBuilder.DropPrimaryKey(
                name: "PK_LearningResult",
                table: "LearningResult");

            migrationBuilder.RenameTable(
                name: "TestResult",
                newName: "TestResults");

            migrationBuilder.RenameTable(
                name: "LearningResult",
                newName: "LearningResults");

            migrationBuilder.RenameIndex(
                name: "IX_TestResult_UserId",
                table: "TestResults",
                newName: "IX_TestResults_UserId");

            migrationBuilder.RenameIndex(
                name: "IX_LearningResult_UserId",
                table: "LearningResults",
                newName: "IX_LearningResults_UserId");

            migrationBuilder.RenameIndex(
                name: "IX_LearningResult_ExerciseId",
                table: "LearningResults",
                newName: "IX_LearningResults_ExerciseId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_TestResults",
                table: "TestResults",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_LearningResults",
                table: "LearningResults",
                column: "Id");

            migrationBuilder.InsertData(
                table: "Lessons",
                columns: new[] { "Id", "Description", "Name" },
                values: new object[,]
                {
                    { 1, "Introduction to Programming", "Lesson 1" },
                    { 2, "Object-Oriented Programming", "Lesson 2" }
                });

            migrationBuilder.InsertData(
                table: "TestingMaterials",
                columns: new[] { "Id", "Text" },
                values: new object[,]
                {
                    { 1, "Lorem ipsum dolor sit amet, consectetur adipiscing elit." },
                    { 2, "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Email", "Password" },
                values: new object[,]
                {
                    { 1, "user1@example.com", "password1" },
                    { 2, "user2@example.com", "password2" }
                });

            migrationBuilder.InsertData(
                table: "Exercises",
                columns: new[] { "Id", "LessonId", "Name", "StudySet" },
                values: new object[,]
                {
                    { 1, 1, "Exercise 1", "Set A" },
                    { 2, 1, "Exercise 2", "Set B" },
                    { 3, 2, "Exercise 3", "Set C" }
                });

            migrationBuilder.InsertData(
                table: "TestResults",
                columns: new[] { "Id", "Accuracy", "Speed", "UserId" },
                values: new object[,]
                {
                    { 1, 75, 55, 1 },
                    { 2, 80, 65, 2 }
                });

            migrationBuilder.InsertData(
                table: "UserLessons",
                columns: new[] { "Id", "LessonId", "UserId" },
                values: new object[,]
                {
                    { 1, 1, 1 },
                    { 2, 2, 2 }
                });

            migrationBuilder.InsertData(
                table: "LearningResults",
                columns: new[] { "Id", "Accuracy", "ExerciseId", "Speed", "UserId" },
                values: new object[,]
                {
                    { 1, 85, 1, 60, 1 },
                    { 2, 90, 2, 70, 2 }
                });

            migrationBuilder.AddForeignKey(
                name: "FK_LearningResults_Exercises_ExerciseId",
                table: "LearningResults",
                column: "ExerciseId",
                principalTable: "Exercises",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_LearningResults_Users_UserId",
                table: "LearningResults",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_TestResults_Users_UserId",
                table: "TestResults",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_LearningResults_Exercises_ExerciseId",
                table: "LearningResults");

            migrationBuilder.DropForeignKey(
                name: "FK_LearningResults_Users_UserId",
                table: "LearningResults");

            migrationBuilder.DropForeignKey(
                name: "FK_TestResults_Users_UserId",
                table: "TestResults");

            migrationBuilder.DropPrimaryKey(
                name: "PK_TestResults",
                table: "TestResults");

            migrationBuilder.DropPrimaryKey(
                name: "PK_LearningResults",
                table: "LearningResults");

            migrationBuilder.DeleteData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "LearningResults",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "LearningResults",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "TestResults",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "TestResults",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "TestingMaterials",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "TestingMaterials",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "UserLessons",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "UserLessons",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Lessons",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Lessons",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.RenameTable(
                name: "TestResults",
                newName: "TestResult");

            migrationBuilder.RenameTable(
                name: "LearningResults",
                newName: "LearningResult");

            migrationBuilder.RenameIndex(
                name: "IX_TestResults_UserId",
                table: "TestResult",
                newName: "IX_TestResult_UserId");

            migrationBuilder.RenameIndex(
                name: "IX_LearningResults_UserId",
                table: "LearningResult",
                newName: "IX_LearningResult_UserId");

            migrationBuilder.RenameIndex(
                name: "IX_LearningResults_ExerciseId",
                table: "LearningResult",
                newName: "IX_LearningResult_ExerciseId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_TestResult",
                table: "TestResult",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_LearningResult",
                table: "LearningResult",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_LearningResult_Exercises_ExerciseId",
                table: "LearningResult",
                column: "ExerciseId",
                principalTable: "Exercises",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_LearningResult_Users_UserId",
                table: "LearningResult",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_TestResult_Users_UserId",
                table: "TestResult",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
