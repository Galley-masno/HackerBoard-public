﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace KeyboardMasterBackend.Migrations
{
    /// <inheritdoc />
    public partial class m7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Name", "StudySet" },
                values: new object[] { "Exercise 1. Right hand", "торт рот горн тон 7 нот гот трон гонг норт грон" });

            migrationBuilder.UpdateData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "Name", "StudySet" },
                values: new object[] { "Exercise 2. Left hand", "мак мапа 6 кемп капа пика 5 мека емка ким кепа ака" });

            migrationBuilder.UpdateData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "Name", "StudySet" },
                values: new object[] { "Exercise 3. Right hand", "лоб лор лот 8 робот лоно борт троль роль бронь горб льон" });

            migrationBuilder.InsertData(
                table: "Exercises",
                columns: new[] { "Id", "LessonId", "Name", "StudySet" },
                values: new object[] { 4, 2, "Exercise 4. Left hand", "кава сам пив сума каса впав свап миска 4 пас ваму спав маска вуса мис" });

            migrationBuilder.UpdateData(
                table: "Lessons",
                keyColumn: "Id",
                keyValue: 1,
                column: "Description",
                value: "Вказівні пальці");

            migrationBuilder.UpdateData(
                table: "Lessons",
                keyColumn: "Id",
                keyValue: 2,
                column: "Description",
                value: "Середні пальці");

            migrationBuilder.InsertData(
                table: "Lessons",
                columns: new[] { "Id", "Description", "Name" },
                values: new object[,]
                {
                    { 3, "Безіменні пальці", "Lesson 3" },
                    { 4, "Мізинці", "Lesson 4" }
                });

            migrationBuilder.InsertData(
                table: "Exercises",
                columns: new[] { "Id", "LessonId", "Name", "StudySet" },
                values: new object[,]
                {
                    { 5, 3, "Exercise 5. Right hand", "шлюб щоб людно 9 борщ лорд блонд люд щодо дощ трою одоробло" },
                    { 6, 3, "Exercise 6. Left hand", "цікава чек сік укіс вік сів чув 3 чіп мавік сумі віспа" },
                    { 7, 4, "Exercise 7. Right hand", "хор зроз хлор їдло. Єн ложо 0 + 9 = 9. Озноб блює" },
                    { 8, 4, "Exercise 8. Left hand", "Фікція вій Якім фея 2 свій мій 1 вія смакуй Майя кип'я" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Lessons",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Lessons",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.UpdateData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Name", "StudySet" },
                values: new object[] { "Exercise 1", "Set A" });

            migrationBuilder.UpdateData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "Name", "StudySet" },
                values: new object[] { "Exercise 2", "Set B" });

            migrationBuilder.UpdateData(
                table: "Exercises",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "Name", "StudySet" },
                values: new object[] { "Exercise 3", "Set C" });

            migrationBuilder.UpdateData(
                table: "Lessons",
                keyColumn: "Id",
                keyValue: 1,
                column: "Description",
                value: "Introduction to Programming");

            migrationBuilder.UpdateData(
                table: "Lessons",
                keyColumn: "Id",
                keyValue: 2,
                column: "Description",
                value: "Object-Oriented Programming");
        }
    }
}
